YAHOO.env.classMap = {"TouchBar": "GameLibs", "GamePad": "GameLibs", "GamePacket": "GameLibs", "Parallax": "GameLibs", "ProximityManager": "gskinner", "GameMediator": "Atari", "FPSMeter": "GameLibs", "SpriteSheetWrapper": "GameLibs", "FramePacket": "GameLibs", "Rnd": "gskinner", "Game": "Game", "KeyCodes": "GameLibs", "Pool": "GameLibs", "ScoreManager": "GameLibs", "ArcadeButton": "GameLibs", "Throttle": "GameLibs", "GameDetails": "GameLibs", "GameShell": "Atari", "Atari": "Atari", "ParticleEmitter": "GameLibs", "MultiPlayerGame": "GameLibs", "GameLibs": "GameLibs", "GameBootstrap": "Atari", "GameUI": "GameLibs", "MultiPlayer": "GameLibs", "StringUtils": "GameLibs", "Player": "GameLibs", "Math2": "GameLibs", "JoyStick": "GameLibs", "PerformanceMonitor": "GameLibs"};

YAHOO.env.resolveClass = function(className) {
    var a=className.split('.'), ns=YAHOO.env.classMap;

    for (var i=0; i<a.length; i=i+1) {
        if (ns[a[i]]) {
            ns = ns[a[i]];
        } else {
            return null;
        }
    }

    return ns;
};
